%Orig earthquake params + best models
%11.27.2005
%Iranian national Broad-band seismic network (INSN) at IIEESS, 26.87N, 55.83E Mb7.2, Ml5.6, 5.9Mb aftershock
%USGS strike/dip/rake 249/45/91 10km depth centroid .73x1018 moment, MW 5.9
%CMT 257/39/83 depth 12km centroid, 1.03x1018mom, Mw 5.9
%nissen insar 267+-2/49+4/105+-5/ slip .88+-.3, zt 3.9+-.4 z0+-.4 L8.4+-.4, mom 1.27e18+-.07, Mw 6.0
%IRIS
