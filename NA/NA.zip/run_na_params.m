%datafiles={'../T435/051124-051229.mat','../T242/040708-051215.mat','../T328/050105-051221.mat','../T328/050525-060125.mat'};
%datafiles={'../T328/050105-051221.mat'};
%datafiles={'../T328/050105-060125.mat'};
%datafiles={'../T328/050525-060125.mat'};
%datafiles={'../T328/050525-051221.mat'};
%datafiles={'/Users/barnhartw/Desktop/Cornell/Qeshm/p566_080905_081021.mat','/Users/barnhartw/Desktop/Cornell/Qeshm/051124-051229.mat'};
datafiles={'/mnt/disk2/rlohman/Iran/T349/F2934/int_960524_980911/T349_960524_980911.mat'};
%datafiles={'/Users/barnhartw/Desktop/Cornell/Qeshm/051124-051229.mat'};
%datafiles={'../T242/040708-051215.mat'};

%na params
ns       = 100; %initial # samples
niter    = 5;   % # iterations
nr       = 2;  % # resamples 
nn       = 200;  % # new ones in each resampled cell 

Lp       = 20;
Wp       = 10;
xytype   = 1;    %1 = radius & angle, 2=x,y, 3=ra +aa

drake   = 0;    %allow range of rake values. 0 fixes rake, 0 if Npatch=1
smoo    = 1; %only used if Lp*Wp>1 

%search ranges: 2 values or empty
p.radius = [0e3 5e3]; 
p.angle  = [-180 180]; % 0 is north
p.strike = [0 360];   %[69 77]; % usgs to cmt usgs to nissen [69 87]
p.dip    = [90 90];   %[39 45]; %cmt to usgs, cmt-nissen [39 50]
p.rake   = [0 180]; %[-91 -83];%usgs to cmt nissen-cmg = [-105 -83] (or180-?)
p.L      = [2e3 10e3];%[2e3 10e3];
p.W      = [2e3 10e3];%[2e3 10e3];
p.zs     = [6000 10000]; %[10e3 12e3]; center of fault plane, mean of L and W
p.Zrange = [0 10e3]; %
p.area   = [0 10e8];% area
p.asp    = [-1 0]; % aspect
%xytype values set one of these pairs
p.xref   = [ 392000];
p.yref   = [2964200];
%p.xs     = [3.9e5 3.94e5];
%p.ys     = [2.964e6 2.948e6];


%CMT: 
%051127 Lat 26.66 Lon 55.80 depth 12.0 Mw=5.9, M0=1.03e+25 strike 257 dip39 rake 83
%or 26.77 55.86 dep 10 Mw 5.9
