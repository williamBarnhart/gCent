function y =myfunFreed(x,Xx);

y = x(3)+x(1)*log(1+Xx/x(2));